import React from "react";

const UnAuthorized = () => {
     return <div>UnAuthorized
 </div>;
}
export default UnAuthorized;
